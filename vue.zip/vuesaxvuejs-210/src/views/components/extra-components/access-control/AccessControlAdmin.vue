<template>
	<vx-card title="Private Content">
    <p>Only admins can see this content.</p>
  </vx-card>
</template>